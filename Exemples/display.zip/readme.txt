This is the simple graphics display sample from
www.loirak.com/gameboy/gbatutor.html

This is part of the tutorial at the above location.
In order to comile run make.bat, to use your own
image. Just overwrite the image called ppic.pcx
with your own 256 color pcx, and then at a dos prompt,
when you are in this directory. Type

pcx2gba ppic.pcx

then press enter, and it will generate a new header
file, then you simply have to run make again.

For an explanation of this code goto the above page.


